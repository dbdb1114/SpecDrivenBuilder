# 작업자 프롬프트

`frontend/` 에서 Claude Code 를 열고 아래 블록을 **번호 순서대로 하나씩** 붙여 넣는다.
각 단계가 끝나면 화면을 직접 확인하고 다음 블록으로 넘어간다.

---

## 0. 시작 프롬프트

```
docs/design/frontend-redesign/ 의 시안대로 빌더 프론트엔드를 새로 만든다.

먼저 읽을 것 (이 순서로):
1. ../AGENTS.md, ./AGENTS.md  — 규칙이 이 프롬프트보다 우선
2. docs/design/frontend-redesign/README.md
3. flow.md, screens.md, api-contract.md, design-tokens.md, motion.css
4. design-source/*.dc.html 은 레이아웃·문구 참고용. 문법(<x-dc>, <sc-if>, {{ }})을 따라 하지 말 것

이번 단계에서 할 것:
- 루트 AGENTS.md 작업 절차대로 docs/work/<YYMMDD>-frontend-redesign/plan.md 작성
- plan.md 에 화면 5개(홈 / 인터뷰·생성 / 다운로드 / 리뷰)와 전환 T1–T9 를 어떤 파일·컴포넌트로 나눌지 적기
- 아래 3가지는 정하지 말고 나에게 선택지로 물어볼 것 (번호 + 추천 표시):
  a. 스타일 방식 (CSS Modules / Tailwind)
  b. 라우팅 라이브러리 추가 여부
  c. 질문 구조화: 백엔드가 options[] 를 준다(A) / 프론트가 파싱한다(B)
- 백엔드 API 는 아직 없다. src/api/ 에 api-contract.md 형태의 목(mock)을 두고, 실제 fetch 로 바꾸기 쉽게 함수 단위로 분리

코딩은 내가 plan.md 와 3가지 답을 확인한 뒤에 시작한다.
```

---

## 1. 기반 · 홈 (T1)

```
plan.md 대로 시작한다. 이번 단계 범위: 공통 레이아웃 + 01 홈 + T1.

- design-tokens.md 의 색·글꼴·간격을 전역 토큰으로. 강조색은 CSS 변수 --ac 하나로
- motion.css 를 정한 스타일 방식으로 옮기기 (prefers-reduced-motion 포함)
- 공통 헤더: 단계 표시 4개는 현재 라우트에서 계산 (상태 따로 두지 말 것)
- 홈: screens.md "01 홈" 전부. 빈 입력이면 "설계 시작" 비활성
- 입력창 Enter 제출 시 한글 조합 중(e.nativeEvent.isComposing)이면 무시
- T1: createSession(request) → /s/:id 로 이동. 실패하면 입력창 아래 오류 + 다시 시도, 화면 유지

끝나면: 홈 화면 확인 방법과 바꾼 파일 목록을 알려줘.
```

---

## 2. 인터뷰 · 생성 중 (T2, T3, T4)

```
이번 단계 범위: /s/:id 화면 (screens.md "02 인터뷰 / 03 생성 중") + T2·T3·T4.

- 진입 시 getSession(id) 로 qa·question·status 복원 (새로고침해도 이어져야 함)
- 질문 UI 는 frontend/AGENTS.md 규칙: 번호 버튼 + 추천 배지 + "직접 입력". 자유 입력만 두지 말 것
- 답변 전송 중에는 답변 도크를 숨기고 타이핑 점 표시 → 중복 전송 막기
- 메시지 목록은 새 메시지가 오면 맨 아래가 보이게
- 진행 바: progress.expected 가 있으면 %, 없으면 "질문 n개째"
- 응답이 status: "generating" 이면 도크 → 생성 표시로 전환(T3), getSession 1초 폴링
- files[].state 로 오른쪽 파일 행 상태 표시. waiting→done 바뀌는 순간에만 flash
- 오른쪽 "spec.md — 실시간 작성" 창은 지금까지의 답 요약임. 생성된 spec 처럼 보이는 문구 쓰지 말 것
- status: "done" 이 되면 마지막 flash 후 0.9초 뒤 /s/:id/done 으로 이동(T4)
- 폴링은 화면을 떠나면 반드시 정리

끝나면: 목 데이터로 질문 4개 → 생성 → 완료까지 한 번에 흘러가는지 확인하고 알려줘.
```

---

## 3. 다운로드 (T5, T8)

```
이번 단계 범위: /s/:id/done (screens.md "04 다운로드") + T5·T8.

- slug 는 백엔드 응답에서 받는다. 없으면 "my-project". 프론트에서 한글 → 영문 변환 로직 만들지 말 것
- zip 다운로드: GET /api/sessions/:id/download 를 <a href download> 로. JS 로 blob 만들지 말 것
- 실행 안내 3단계 코드 줄에 복사 버튼 추가 (복사 후 1.5초 "복사됨")
- "미리보기·수정" → /s/:id/review (T5)
- "새 프로젝트" → / (T9)

끝나면: 다운로드 링크가 맞는 URL 을 가리키는지 알려줘.
```

---

## 4. 리뷰 (T6, T7, T8)

```
이번 단계 범위: /s/:id/review (screens.md "05 리뷰") + T6·T7·T8.

- getArtifacts(id) 로 파일 5개 내용 로드. 읽기 보기 = 마크다운 줄 단위 서식(#, ##, -, 1., - [ ]), 원문 보기 = 고정폭
  마크다운 라이브러리가 필요하면 먼저 물어볼 것 (상태 관리 라이브러리와 같은 규칙으로 취급)
- 줄 클릭 = 선택/해제. 선택 줄이 있으면 요청에 { file, line } 같이 보냄
- 요청 → createRevision → 응답의 file 탭으로 전환하고 diff 를 그대로 렌더 (+ 강조색 / − 주황·취소선)
  diff 계산은 백엔드가 한다. 프론트에서 diff 만들지 말 것
- 제안 바의 적용/되돌리기 → accept/reject. 적용하면 version 갱신, 그 파일 탭에 변경 점
- 제안이 떠 있는데 새 요청: 기존 제안은 reject 하지 말고 화면에서만 버리기 [미확인 — 백엔드 동작 정해지면 맞출 것]
- "확정하고 다운로드" → 토스트 + 3단계와 같은 다운로드 링크

끝나면: 목 데이터로 요청 → 제안 → 적용 → 버전 증가 → 다운로드까지 확인하고 알려줘.
```

---

## 5. 마무리

```
마무리 점검:
- 폭 390px 에서 모든 화면이 가로 스크롤 없이 세로로 쌓이는지
- 키보드만으로 홈 → 인터뷰 → 다운로드 → 리뷰가 되는지 (Tab, Enter, 포커스 링)
- prefers-reduced-motion 에서 애니메이션이 꺼지는지
- npm run lint, npm run test 통과
- 컴포넌트 안에 fetch 가 없는지 (src/api/ 경유만)
- plan.md 에 남은 [미확인] 목록을 정리해서 알려줘
```

---

## 이동 사이에 넣을 수 있는 짧은 프롬프트

| 상황 | 붙여 넣을 말 |
|---|---|
| 화면이 시안과 다를 때 | `design-source/Main.dc.html 의 <해당 부분>과 비교해서 간격·크기·색을 맞춰. 다른 곳은 건드리지 마` |
| 애니메이션이 과할 때 | `design-tokens.md 모션 표에 있는 것만 남기고 나머지 전환 효과는 빼` |
| 전환이 끊길 때 | `flow.md 의 T<n> 전환 연출대로 다시 맞춰. 화면 진입 시 rise stagger 가 다시 재생돼야 해` |
| 백엔드가 생겼을 때 | `npm run gen:types 로 타입 생성하고 src/api/ 목을 실제 호출로 바꿔. api-contract.md 와 다른 점을 먼저 알려줘` |
| 범위를 넘을 때 | `이번 단계 범위 밖이야. plan.md 에 TODO 로만 적고 멈춰` |
