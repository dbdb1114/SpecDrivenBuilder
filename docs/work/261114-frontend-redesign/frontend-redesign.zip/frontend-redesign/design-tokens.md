# 디자인 토큰

## 색

| 토큰 | 값 | 용도 |
|---|---|---|
| `bg` | `#0A0A0C` | 페이지 배경 |
| `grid` | `#16161A` | 배경 격자선 (64px) |
| `surface` | `#0E0E11` | 패널 |
| `surface-2` | `#111115` | 입력창 · 선택지 카드 |
| `surface-3` | `#18181D` | 봇 말풍선 · 선택 탭 |
| `line` | `#1F1F25` | 패널 안 구분선 |
| `line-2` | `#23232A` / `#2E2E36` | 패널 테두리 / 버튼 테두리 |
| `text` | `#F2F2F0` | 본문, 사용자 말풍선 배경 |
| `text-2` | `#DADAE0` | 보조 본문 |
| `muted` | `#B4B4BC` / `#8E8E98` | 설명 / 라벨 |
| `accent` | `#D4FF3A` | 주 버튼 · 추천 · 완료 · 추가된 줄. 위 글자는 항상 `bg` |
| `warn` | `#FF6B2C` | 삭제된 줄 (diff) 전용 |

대체 강조색(디자인 Tweaks): `#FF6B2C`, `#7CC7FF`, `#F2F2F0`. CSS 변수 `--ac` 하나로 바꿀 수 있게 만들 것.

## 글꼴 (Google Fonts)

- 제목: `Space Grotesk` 700 → 한글은 `Noto Sans KR` 900 으로 떨어짐. 자간 `-0.045em`, 줄간 1.02
- 본문: `Noto Sans KR` 400/500/700
- 코드·라벨·파일명: `JetBrains Mono` 400/600, 라벨은 11px · 자간 .08em · 대문자

크기: 히어로 `clamp(48px, 8.4vw, 124px)` · 완료 화면 `clamp(44px, 7vw, 104px)` · 본문 15px · 라벨 11–13px

## 모서리 · 간격

- 패널 22px · 입력창 14–20px · 버튼 12–16px · 칩/알약 999px · 작은 상자 7–10px
- 패널 사이 18–20px, 페이지 좌우 `clamp(16px, 4vw, 48px)`, 최대 폭 1280–1400px

## 모션 (원본: `motion.css`)

| 이름 | 시간 · 곡선 | 쓰는 곳 |
|---|---|---|
| `up` | .7–.8s `cubic-bezier(.16,.84,.24,1)` | 화면 진입 요소, 80–180ms 간격 stagger |
| `pop` | .45–.5s 같은 곡선 | 말풍선 · 선택지 · 칩 |
| `slide` | .55s | 파일 행 · 탭 |
| `cycle` | 7s `cubic-bezier(.8,0,.2,1)` 무한 | 히어로 회전 단어 |
| `marq` | 26s linear 무한 | 하단 파일명 띠 |
| `bounce` | 1.1s 무한, 점마다 .15s 지연 | 타이핑 표시 |
| `flash` | .9s ease-out | 파일 완료 순간 |
| `scan` | 1.6s 무한 | 생성 중 패널 |
| `ping` | 1.4s 무한 | 수정된 파일 점 |
| 버튼 hover | .18s, `translateY(-2px)` / active `scale(.98)` | 모든 버튼 |
| 진행 바 | width .7s | 인터뷰 진행 |

화면 전환(T1·T4·T5)은 라우트 단위로 `up` 을 다시 재생하면 된다. View Transitions API 는 선택.
